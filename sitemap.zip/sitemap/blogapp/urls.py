from django.urls import path
from . import views
from django.views.generic import TemplateView

urlpatterns = [
    path('',views.HomeView, name='home'),
   # Pages View
    path('privacy-policy/',views.PrivacyView, name='privacy'),
    path('disclaimer/',views.DisclaimerView, name='disclaimer'),
    path('terms-and-condition/',views.TermsView, name='terms'),
    path('contact-us/',views.ContactView, name='contact'),
    # end
    path('<slug:slug>/',views.PostView, name='post_detail'),
    path('search',views.SearchView, name='search'),
    path('category/<slug:slug>/', views.CategoryView, name='category'),
   
]