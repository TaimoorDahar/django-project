// adsloaded=false;
// $(document).click(activateAds);
// $(document).scroll(activateAds);
// $(document).mousemove(activateAds);
// function activateAds(){
// 	if(!adsloaded){
// 		(function(d, script) {
// 			script = d.createElement('script');
// 			script.type = 'text/javascript';
// 			script.async = true;
// 			script.crossorigin="anonymous";
// 			script.onload = function(){
// 				// remote script has loaded
// 			};
// 			script.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8207541904035788';
// 			d.getElementsByTagName('head')[0].appendChild(script);
// 		}(document));
		
// 		$(".theadd").each(function(){
// 			$(this).html('<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-8207541904035788" data-ad-slot="4853625528" data-ad-format="auto" data-full-width-responsive="true"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>');
// 		});
// 		adsloaded=true;
// 	}
// }