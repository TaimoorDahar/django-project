from turtle import home
from unicodedata import category, name
from django.shortcuts import render
from django.views.generic import TemplateView
from django.core.mail import BadHeaderError, send_mail
from django.http import HttpResponse, HttpResponseRedirect
from blogapp.models import Post,Category
from django.core.paginator import Paginator
from django.views.generic import ListView
from django.shortcuts import get_object_or_404

# Create your views here.



def HomeView(request):
    Homedata = Post.objects.all().order_by('-id')[:3]
    Catdata = Category.objects.all()
    homepaginator = Paginator(Homedata,3)
    page_number = request.GET.get('page')
    page_obj = homepaginator.get_page(page_number)
    
    
    def get_context_data(self, **kwargs):
        cat_menu = Category.objects.all()
        context = super(HomeView,self).get_context_data(**kwargs)
        context["cat_menu"] = cat_menu
        return context
    

    
    
    Blogpost = {
        'Homedata':Homedata,
        'page_obj':page_obj,
        'Catdata':Catdata,
        
    }
      
    
    
    return render(request, 'home.html',Blogpost)


    # Post Detail Code
def PostView(request,slug):
    Catdata = Category.objects.all()
    Postdata = Post.objects.get(slug=slug)
    Cate_Post = Post.objects.all().filter().order_by('-id')
    side_data = Post.objects.all()
    return render(request,'post-detail.html',{'Postdata':Postdata,'side_data':side_data,'Cate_Post':Cate_Post,'Catdata':Catdata})



def SearchView(request):
    Catdata = Category.objects.all()
    side_data = Post.objects.all()
    if request.method == "POST":
        searched = request.POST['searched']
        search_result = Post.objects.filter(title__icontains = searched)
        return render(request,'search.html',{'search_result':search_result,'searched':searched,'Catdata':Catdata,'side_data':side_data})
    else:
        return render(request,'search.html')
    return render(request,'search.html')

def CategoryView(request,slug):
    Catdata = Category.objects.all()
    category_posts = Post.objects.filter(category__cat_slug=slug).order_by('-id')
    homepaginator = Paginator(category_posts,6)
    page_number = request.GET.get('page')
    page_obj = homepaginator.get_page(page_number)
    return render(request,'category.html',{'page_obj':page_obj,'Catdata':Catdata})



# Pages Functions

def PrivacyView(request):
    Catdata = Category.objects.all()
    return render(request,'privacypolicy.html',{'Catdata':Catdata})
def DisclaimerView(request):
    Catdata = Category.objects.all()
    return render(request,'disclaimer.html',{'Catdata':Catdata})

def TermsView(request):
    Catdata = Category.objects.all()
    return render(request,'termsandconditions.html',{'Catdata':Catdata})

def ContactView(request):
    Catdata = Category.objects.all()
    if request.method == 'POST':
        name = request.POST.get('name')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        email = request.POST.get('email')
        data ={
            'name':name,
            'email':email,
            'subject':subject,
            'message':message,
        }
        message = '''
        New message:{}
        From: {}
        '''.format(data['message'],data['email'])
        send_mail(data['subject'],message,'',['jcrvisofficial@gmail.com'])
    return render(request,'contactus.html',{'Catdata':Catdata})    