from django.db import models
from froala_editor.fields import FroalaField
from django.contrib.auth.models import User
from django.utils.text import slugify

class Category(models.Model):
    name = models.CharField(max_length=100,unique=True)
    category_description = FroalaField()
    cat_slug = models.SlugField(max_length=200, null=False,unique=True)

    class Meta:
        verbose_name = ("Category")
        verbose_name_plural = ("Categories")

    def __str__(self):
        return self.name

options = (
        ('draft', 'Draft'),
        ('published', 'Published'),
    )

class Post(models.Model):
    title = models.CharField(max_length=200, unique=True)
    slug = models.SlugField(max_length=200, null=False, unique=True)
    category = models.ForeignKey(
    Category, on_delete=models.CASCADE,null=True,)
    author = models.ForeignKey(User, on_delete= models.CASCADE,related_name='myapp_post')
    updated_on = models.DateTimeField(auto_now= True)
    content = FroalaField()
    feature_img = models.ImageField(upload_to = 'images/', null=False)
    status = models.CharField(max_length=10, choices=options, default='draft')
    created_on = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('-created_on', )
 
    def __str__(self):
        return self.title


    def get_absolute_url(self):
        from django.urls import reverse
        return reverse("post_detail", kwargs={"slug": str(self.slug)})
   
    class Meta:  
        db_table = "myapp_post"
   
    def save(self, *args, **kwargs):
        value = self.title
        self.slug = slugify(value, allow_unicode=True)
        super().save(*args, **kwargs)